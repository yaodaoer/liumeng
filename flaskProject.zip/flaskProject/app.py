from flask import Flask, render_template, request, redirect, url_for
from my_sqlite import *

app = Flask(__name__)


def process_data(form):
    data = dict(
        stu_id=form["stu_id"],
        stu_name=form["stu_name"],
        stu_sex=form["stu_sex"],
        stu_age=form["stu_age"],
        stu_origin=form["stu_origin"],
        stu_profession=form["stu_profession"],
    )
    return data


@app.route("/", methods=["GET"])
def show_data():
    rows, fields = exec_sql(
        "select s.* ,p.profession_name from student_info s join profession_info p on s.stu_profession = p.profession_id")
    return render_template("show_table.html", rows=rows, fields=fields)


@app.route("/add", methods=["GET"])
def add():
    return render_template("submit_table.html", action="add", data="")


@app.route("/delete/<_id>", methods=["GET"])
def delete(_id):
    delete_data_by_id("stu_id", _id, "student_info")
    return redirect(url_for("show_data"))


@app.route("/delete_selected/<ids>", methods=["GET"])
def delete_selected(ids):
    for _id in ids.split(","):
        delete_data_by_id("stu_id", _id, "student_info")
    return redirect(url_for("show_data"))


@app.route("/update/<id>", methods=["GET"])
def update(id):
    result, _ = exec_sql(f"select * from student_info where stu_id='{id}'")
    return render_template("submit_table.html", action="update", data=result[0])


@app.route("/save/<action>", methods=["POST"])
def save(action):
    if action == "add":
        data = process_data(request.form)
        insert_data(data, "student_info")
        return redirect(url_for("show_data"))
    else:
        data = process_data(request.form)
        update_data(data, "student_info")
        return redirect(url_for("show_data"))


if __name__ == "__main__":
    app.run()
