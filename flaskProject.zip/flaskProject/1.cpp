#include <bits/stdc++.h>
using namespace std;
using LL = long long;
const int maxn = 1e5 + 5;
const int mod = 1e7 + 7;
class Solution {
 public:
  long long countPairs(int n, vector<vector<int>>& edges) {}
};
template <typename T>
inline T next() {
  T x;
  cin >> x;
  return x;
}
void untie() {
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
}
void solve() { return; }
int main() {
  untie();
  int T = 1;
  // int T = next<int>();
  while (T--) solve();
  return 0;
}