import sqlite3

database = "./student.db"


# 连接数据库
def connect_db():
    conn = sqlite3.connect("student.db")
    return conn


def exec_sql(sql, values=''):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(sql, values)
    fields = []
    for field in cursor.description:
        fields.append(field[0])
    result = cursor.fetchall()
    cursor.close()
    return result, fields


def show_table_columns_name(table_name):
    conn = connect_db()
    cursor = conn.cursor()
    # 获取数据
    cursor.execute(f"pragma table_info({table_name})")
    columns = cursor.fetchall()
    fields = [column[1] for column in columns]
    conn.close()
    return fields


# 显示表全部信息
def show_all_table(table_name):
    conn = connect_db()
    cursor = conn.cursor()
    # 获取数据
    cursor.execute(f"select * from {table_name}")
    rows = cursor.fetchall()
    # 获取列名
    cursor.execute(f"pragma table_info({table_name})")
    columns = cursor.fetchall()
    fields = [column[1] for column in columns]
    conn.close()
    return rows, fields


def update_data(data, table_name):
    conn = connect_db()
    values = []
    id_name = list(data)[0]
    for col in list(data)[1:]:
        values.append(f"{col}='{data[col]}'")
    cursor = conn.cursor()
    sql = (
        f"update {table_name} set {','.join(values)} where {id_name}='{data[id_name]}'"
    )
    cursor.execute(sql)
    conn.commit()
    conn.close()


def insert_data(data, table_name):
    conn = connect_db()
    values = []
    cursor = conn.cursor()
    field_name = list(data)
    # 获取要插入的数据
    for col in field_name:
        values.append(data[col])
    sql = f'insert into {table_name} ({",".join(field_name)}) values({",".join(["?"] * len(field_name))})'
    cursor.execute(sql, values)
    conn.commit()
    conn.close()


def delete_data_by_id(id, value, table_name):
    conn = connect_db()
    cursor = conn.cursor()
    sql = f"delete from {table_name} where {id}=?"
    # value 必须以元组的形式作为参数
    cursor.execute(sql, (value,))
    conn.commit()
    conn.close()
