let msgList = Array.from(document.querySelector(".msg").children).map(msg => msg.innerHTML);
let [pageNum, itemNum, totalNum] = msgList;
// console.log(pageNum, itemNum, totalNum);
let select = document.querySelector("select");
select.value = itemNum;
let pagination = document.querySelector(".pagination");
let aLink = document.createElement("a");
let optionValues = document.querySelectorAll("option");
let backToHomeToggle = document.querySelector(".backToHome");

function clearStyle() {
  let aLinks = document.querySelectorAll("a");
  Array.from(aLinks).forEach((aLink) => aLink.classList.remove("active"));
}

for (let i = 0; i < totalNum / itemNum; ++i) {
  let page = aLink.cloneNode(true);
  page.className = i + 1 === parseInt(pageNum) ? "item active" : "item";
  page.innerText = i + 1;
  pagination.appendChild(page);
  page.addEventListener("click", () => {
    clearStyle();
    page.classList.add("active");
    let selectValue = select.value;
    location.href = `/show/${selectValue}/${page.innerText}`;
  });
}

//判断特殊情况
if(pageNum > totalNum / itemNum) {
  pageNum;
}

backToHomeToggle.onclick = () => location.href = "/home";




select.addEventListener("change", () => {
  let selectValue = select.value;
  let aLinks = document.querySelectorAll("a");
  let targetNum = 0;
  Array.from(aLinks).forEach((aLink) => {
    if(aLink.classList.contains("active")) 
      targetNum = aLink.innerText;
  });
  location.href = `/show/${selectValue}/${targetNum}`;
});
